package com.seeyon.apps.nbd.core.config;

/**
 * Created by liuwenping on 2018/8/17.
 */
public final class Hook {

    public static String VERSION="1.0";



}
