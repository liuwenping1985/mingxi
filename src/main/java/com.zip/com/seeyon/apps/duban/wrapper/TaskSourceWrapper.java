package com.seeyon.apps.duban.wrapper;

/**
 * 任务资源包装
 * Created by liuwenping on 2019/11/5.
 */
public class TaskSourceWrapper {


}
