package com.seeyon.apps.duban.vo.hbm;

/**
 * Created by liuwenping on 2019/11/14.
 */
public class ColumnVo {

    private String name;

    private String t_name;

    private String type;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getT_name() {
        return t_name;
    }

    public void setT_name(String t_name) {
        this.t_name = t_name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
