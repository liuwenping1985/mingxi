package com.seeyon.apps.duban.vo.hbm;

/**
 * Created by liuwenping on 2019/11/14.
 */
public class TableVo {

    private String classPath;

    private String tableName;

    public String getClassPath() {
        return classPath;
    }

    public void setClassPath(String classPath) {
        this.classPath = classPath;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
}
