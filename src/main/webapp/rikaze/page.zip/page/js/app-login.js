;(function(){


    alert("wahaha");
}())